import React from 'react'
import {ImageBox,TextBox} from '../../components/index'
const HeroSection = () => {
  return (
    <>HeroSection</>
  )
}

export default HeroSection