import React from 'react'
import {AnimationBox,FeatureHeading} from '../../components/index'
const TopSection = () => {
  return (
    <>TopSection</>
  )
}

export default TopSection