import HeroSection from "./HeroSection/HeroSection";
import TopSection from "./TopSection/TopSection";

export{
    HeroSection,
    TopSection
}
