import { Box } from "@mui/material";
import React from "react";

const Home = () => {
  return (
    <>
     <Box >
Home
     </Box>
    </>
  );
};

export default Home;
