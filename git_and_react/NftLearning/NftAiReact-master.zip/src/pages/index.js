import Home from "./Home/Home";
import Faqs from "./Faqs/Faqs";
export{
    Home,
    Faqs
}