import React from 'react'

const Faqs = () => {
  return (
    <div>Faqs</div>
  )
}

export default Faqs