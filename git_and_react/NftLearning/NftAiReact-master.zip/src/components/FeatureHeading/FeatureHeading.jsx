import React from 'react'

const FeatureHeading = () => {
  return (
    <div>FeatureHeading</div>
  )
}

export default FeatureHeading