import React from 'react'

const AnimationBox = () => {
  return (
    <div>AnimationBox</div>
  )
}

export default AnimationBox