import React from 'react'

const ImageBox = () => {
  return (
    <div>ImageBox</div>
  )
}

export default ImageBox