import React from 'react'

const TextBox = () => {
  return (
    <div>TextBox</div>
  )
}

export default TextBox